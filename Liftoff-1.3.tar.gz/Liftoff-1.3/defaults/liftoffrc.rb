pre_action do
	
  # podfile do
  #   pod 'NWVersion', :git => 'https://github.com/woodnathan/NWVersion.git'
  # end
	
end

project do
	
end

post_action do
  
  # Install SOCK
  # Note that hooks aren't synced
	git_download 'git@github.com:neciu/SOCK.git', include: [ 'sock-sort.sh', 'pysock' ]
	command 'ln -s sock-sort.sh pre-commit'
	chmod 555, 'pre-commit'
	
end