require 'tempfile'

module Liftoff
	module DSL
		
		class DSLBase
			
			def command (cmd)
				%x{ #{cmd} }
			end
			
		end
		
	end
end