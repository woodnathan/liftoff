module Liftoff
	module DSL
		
		class Podfile < DSLBase
			PODFILE_NAME = 'Podfile'
			
			def initialize
				raise 'Podfile exists' if File.exists? PODFILE_NAME
				@file = File.open(PODFILE_NAME, 'w')
			end
			
			def close
				@file.close
			end
			
			def pod (name, **requirements)
				reqs = requirements.map { |k, v| ":#{k.to_sym} => '#{v}'" }.join(', ') # Need to investigate to_sym more
				@file.puts("pod '#{name}'#{', ' if requirements.length > 0}#{reqs}")
			end
			
		end
		
	end
end