module Liftoff
	class DSLFile
    
    attr_reader :pre_actions, :project_actions, :post_actions
		
		def initialize(path = nil)
			@pre_actions = []
			@project_actions = []
			@post_actions = []
      
      if path
  			self.instance_eval IO.read(path), path
      end
		end
		
		def run(project_configuration)
			execute_procs @pre_actions
			
      execute_procs @project_actions, project_configuration
      
      yield if block_given?
      
			execute_procs @post_actions
		end
		
		def pre_action (&block)
			@pre_actions << block
		end
		
		def project (&block)
			@project_actions << block
		end
		
		def post_action (&block)
			@post_actions << block
		end
    
    def merge (other_file)
      new_file = self.class.new

      new_file.pre_actions.concat(self.pre_actions)
      new_file.pre_actions.concat(other_file.pre_actions)
      
      new_file.project_actions.concat(self.project_actions)
      new_file.project_actions.concat(other_file.project_actions)
      
      new_file.post_actions.concat(self.post_actions)
      new_file.post_actions.concat(other_file.post_actions)
      
      new_file
    end
		
		private
		
		def execute_procs (array, instance = nil)
      instance ||= DSL::DSLHelper.new
			array.map { |block| instance.instance_eval &block }
		end
		
	end
end