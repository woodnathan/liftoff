module Liftoff
  class CocoapodsSetup

    def install_cocoapods(use_cocoapods, use_template = true)
      if use_cocoapods
        if pod_installed?
          move_podfile if use_template && !File.exists?('Podfile')
          
          if File.exists?('Podfile')
            run_pod_install
          else
              puts 'Creating empty Podfile, but "pod install" will not be run at this time'
              File.open('Podfile', 'w') {}
          end
        else
          puts 'Please install Cocoapods or disable pods from liftoff'
        end
      end
    end

    private

    def pod_installed?
      `which pod`
      $?.success?
    end

    def move_podfile
      FileManager.new.generate('Podfile', 'Podfile')
    end

    def run_pod_install
      puts 'Running pod install'
      system('pod install')
    end
  end
end
