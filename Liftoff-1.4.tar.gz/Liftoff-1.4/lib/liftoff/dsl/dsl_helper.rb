require 'tempfile'

module Liftoff
	module DSL
    
		class DSLHelper < DSLBase
			
			def podfile (&block)
				file = Podfile.new
				file.instance_eval &block
				file.close
			end
			
			def pod_install
				CocoapodsSetup.new.install_cocoapods(true, false)
			end
			
			def git_init
				GitSetup.new(true).setup
			end
			
			def chmod (mode, path)
				%x{ chmod #{mode} "#{path}" }
			end
      
      def open_project
        %x{ open -a "Xcode" . }
      end
			
			# def symlink(**args)
			# 	raise ArgumentError.new unless args.has_key? :path
			# 	raise ArgumentError.new unless args.has_key? :link
			# 	
			# 	%{ ln -s #{args[:link]} #{args[:path]} }
			# end
			
			# Downloads files from a git repository
			# Due to the way inclusions and exclusions work with the tar command, excludes take precedence
			# The default excludes contain the patterns '.git*' and 'README*'
			# If you intend to download a file matching that pattern, ensure to provide a value for the exclude argument
			def git_download (remote, ref: 'HEAD', include: [], exclude: [ '.git*', 'README*' ])
				include_str = include.collect { |x| "--include='#{x}'" }.join(' ')
				exclude_str = exclude.collect { |x| "--exclude='#{x}'" }.join(' ')
				
				Dir.mktmpdir do |dir|
					%x{ git clone --depth=1 #{remote} #{dir} 2>&1 } # git is quite verbose on stderr, so we just redirect it to stdout
					%x{ cd "#{dir}" && git archive --format=tar #{ref} | tar xf - #{exclude_str} #{include_str} -C "#{Dir.pwd}" }
				end
			end
			
		end
    
	end
end